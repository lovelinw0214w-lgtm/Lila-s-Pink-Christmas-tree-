import React, { Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { Environment, OrbitControls, ContactShadows, Stars } from '@react-three/drei';
import { EffectComposer, Bloom, Vignette, Noise } from '@react-three/postprocessing';
import { MagicTree } from './MagicTree';
import { AppMode } from '../types';
import * as THREE from 'three';

interface SceneProps {
  mode: AppMode;
}

export const Scene: React.FC<SceneProps> = ({ mode }) => {
  return (
    <Canvas
      dpr={[1, 2]}
      camera={{ position: [0, 0, 25], fov: 45 }}
      gl={{ antialias: false, toneMapping: THREE.ReinhardToneMapping, toneMappingExposure: 1.5 }}
    >
      <color attach="background" args={['#0a0406']} />
      
      <Suspense fallback={null}>
        {/* Environment & Lighting */}
        <Environment preset="city" />
        <ambientLight intensity={0.5} color="#ffd1dc" />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} intensity={2} color="#ffc0cb" />
        <pointLight position={[-10, -10, -10]} intensity={1} color="#E0E0E0" />
        
        {/* Cinematic Elements */}
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade speed={1} />
        
        {/* The Tree Content */}
        <MagicTree mode={mode} />

        {/* Floor Reflections */}
        <ContactShadows 
            resolution={1024} 
            scale={50} 
            blur={2} 
            opacity={0.5} 
            far={10} 
            color="#ec407a" 
        />

        {/* Post Processing for the "Glow" */}
        <EffectComposer disableNormalPass>
          <Bloom 
            luminanceThreshold={1.1} 
            mipmapBlur 
            intensity={0.8} 
            radius={0.6}
          />
          <Vignette eskil={false} offset={0.1} darkness={0.6} />
          <Noise opacity={0.02} />
        </EffectComposer>

        <OrbitControls 
            enablePan={false} 
            minDistance={10} 
            maxDistance={40} 
            autoRotate={false}
            maxPolarAngle={Math.PI / 1.4}
        />
      </Suspense>
    </Canvas>
  );
};