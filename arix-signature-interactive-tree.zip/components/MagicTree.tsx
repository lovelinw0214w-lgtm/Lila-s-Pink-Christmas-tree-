import React, { useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { FloatingElement } from './FloatingElement';
import { generateParticles } from '../utils/geometry';
import { AppMode } from '../types';

interface MagicTreeProps {
  mode: AppMode;
}

export const MagicTree: React.FC<MagicTreeProps> = ({ mode }) => {
  const particles = useMemo(() => generateParticles(), []);
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (groupRef.current) {
        // Slowly rotate the entire tree when formed
        if (mode === AppMode.TREE_SHAPE) {
            groupRef.current.rotation.y += 0.002;
        } else {
             // Slower drift when scattered
            groupRef.current.rotation.y += 0.0005;
        }
    }
  });

  return (
    <group ref={groupRef}>
      {particles.map((data) => (
        <FloatingElement key={data.id} data={data} mode={mode} />
      ))}
      
      {/* The Star on Top - Only visible near tree center, we treat it as a special particle or static mesh */}
      <mesh position={[0, 8, 0]} scale={mode === AppMode.TREE_SHAPE ? 1 : 0}>
         <octahedronGeometry args={[1.5, 0]} />
         <meshPhysicalMaterial 
            color="#FFD700" 
            emissive="#FFD700"
            emissiveIntensity={2}
            toneMapped={false}
         />
      </mesh>
    </group>
  );
};