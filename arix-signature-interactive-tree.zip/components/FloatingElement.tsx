import React, { useRef, useMemo } from 'react';
import * as THREE from 'three';
import { useFrame } from '@react-three/fiber';
import { ItemType, ParticleData, AppMode } from '../types';

interface FloatingElementProps {
  data: ParticleData;
  mode: AppMode;
}

// Reusable Geometries to save memory
const boxGeo = new THREE.BoxGeometry(1, 1, 1);
const sphereGeo = new THREE.SphereGeometry(0.6, 32, 32);
const octaGeo = new THREE.OctahedronGeometry(0.5); // Diamond shape
const dodecaGeo = new THREE.DodecahedronGeometry(0.6); // Flower-ish shape

export const FloatingElement: React.FC<FloatingElementProps> = ({ data, mode }) => {
  const meshRef = useRef<THREE.Group>(null);
  
  // Target position logic
  const targetPos = mode === AppMode.TREE_SHAPE ? data.treePosition : data.scatterPosition;
  
  // Animation loop
  useFrame((state, delta) => {
    if (!meshRef.current) return;

    // Smooth Lerp to target position
    // Use a spring-like dampening factor. 
    // We modify the speed slightly per object to make it look organic
    const speed = 2.5 + (data.id % 5) * 0.2;
    
    meshRef.current.position.lerp(targetPos, speed * delta);
    
    // Constant slow rotation for liveliness
    meshRef.current.rotation.x += 0.005;
    meshRef.current.rotation.y += 0.01;
  });

  // Material selection based on aesthetic
  const material = useMemo(() => {
    const isDiamond = data.type === ItemType.DIAMOND;
    const isSilver = data.type === ItemType.ORNAMENT_SILVER;
    const isGift = data.type === ItemType.GIFT;

    if (isDiamond) {
      return (
        <meshPhysicalMaterial
          color="#ffffff"
          transmission={1} // Glass-like
          opacity={1}
          metalness={0}
          roughness={0}
          ior={2.4} // Diamond IOR
          thickness={1.5}
          specularIntensity={1}
          emissive="#ffccff"
          emissiveIntensity={0.2}
        />
      );
    }
    
    if (isSilver) {
      return (
        <meshStandardMaterial
          color="#E0E0E0"
          metalness={1}
          roughness={0.1}
          envMapIntensity={1.5}
        />
      );
    }

    if (isGift) {
       // High gloss plastic/wrapping paper look
       return (
        <meshPhysicalMaterial
          color={data.color}
          metalness={0.3}
          roughness={0.2}
          clearcoat={1}
          clearcoatRoughness={0.1}
        />
      );
    }

    // Flowers and Pink Ornaments
    return (
      <meshStandardMaterial
        color={data.color}
        metalness={0.6}
        roughness={0.3}
        emissive={data.color}
        emissiveIntensity={0.2}
      />
    );
  }, [data.type, data.color]);

  // Select Geometry
  let Geometry = sphereGeo;
  if (data.type === ItemType.GIFT) Geometry = boxGeo;
  if (data.type === ItemType.DIAMOND) Geometry = octaGeo;
  if (data.type === ItemType.FLOWER) Geometry = dodecaGeo;

  return (
    <group 
      ref={meshRef} 
      position={data.scatterPosition} // Initial spawn position
      rotation={data.rotation}
      scale={data.scale}
    >
      <mesh geometry={Geometry}>
        {material}
      </mesh>
      
      {/* Add a ribbon for gifts */}
      {data.type === ItemType.GIFT && (
        <mesh position={[0, 0, 0]} scale={[1.05, 0.2, 1.05]}>
           <boxGeometry />
           <meshStandardMaterial color="#FFFFFF" metalness={0.8} roughness={0.2} />
        </mesh>
      )}
       {data.type === ItemType.GIFT && (
        <mesh position={[0, 0, 0]} scale={[0.2, 1.05, 1.05]}>
           <boxGeometry />
           <meshStandardMaterial color="#FFFFFF" metalness={0.8} roughness={0.2} />
        </mesh>
      )}
    </group>
  );
};