import * as THREE from 'three';

export enum AppMode {
  SCATTERED = 'SCATTERED',
  TREE_SHAPE = 'TREE_SHAPE'
}

export enum ItemType {
  DIAMOND = 'DIAMOND',
  ORNAMENT_SILVER = 'ORNAMENT_SILVER',
  ORNAMENT_PINK = 'ORNAMENT_PINK',
  GIFT = 'GIFT',
  FLOWER = 'FLOWER'
}

export interface ParticleData {
  id: number;
  type: ItemType;
  treePosition: THREE.Vector3;
  scatterPosition: THREE.Vector3;
  rotation: THREE.Euler;
  scale: number;
  color: string;
}