import * as THREE from 'three';
import { ItemType, ParticleData } from '../types';

const COUNT = 350; // Total number of items
const SCATTER_RADIUS = 18;
const TREE_HEIGHT = 14;
const TREE_RADIUS_BASE = 5.5;

// Helper to generate random position in a sphere
const getRandomSpherePos = (radius: number): THREE.Vector3 => {
  const u = Math.random();
  const v = Math.random();
  const theta = 2 * Math.PI * u;
  const phi = Math.acos(2 * v - 1);
  const r = Math.cbrt(Math.random()) * radius;
  const sinPhi = Math.sin(phi);
  return new THREE.Vector3(
    r * sinPhi * Math.cos(theta),
    r * sinPhi * Math.sin(theta),
    r * Math.cos(phi)
  );
};

export const generateParticles = (): ParticleData[] => {
  const particles: ParticleData[] = [];

  for (let i = 0; i < COUNT; i++) {
    // 1. Determine Type based on probability
    const rand = Math.random();
    let type = ItemType.ORNAMENT_SILVER;
    let color = '#E0E0E0'; // Silver default
    let scale = 1;

    if (rand < 0.2) {
      type = ItemType.DIAMOND;
      color = '#ffffff';
      scale = 0.8;
    } else if (rand < 0.4) {
      type = ItemType.GIFT;
      color = Math.random() > 0.5 ? '#F8BBD0' : '#FCE4EC'; // Light Pinks
      scale = 1.2;
    } else if (rand < 0.6) {
      type = ItemType.FLOWER;
      color = '#F48FB1'; // Deeper Pink
      scale = 1.5;
    } else if (rand < 0.8) {
      type = ItemType.ORNAMENT_PINK;
      color = '#F8BBD0';
      scale = 0.9;
    }

    // 2. Calculate Tree Position (Cone Spiral)
    // Normalized height (0 at bottom, 1 at top)
    const h = i / COUNT; 
    const angle = i * 2.4; // Golden angle approx for spiral
    
    // Radius decreases as height increases
    const currentRadius = TREE_RADIUS_BASE * (1 - h);
    
    const x = Math.cos(angle) * currentRadius;
    const z = Math.sin(angle) * currentRadius;
    const y = (h * TREE_HEIGHT) - (TREE_HEIGHT / 2); // Center vertically

    const treePos = new THREE.Vector3(x, y, z);
    
    // Add some random jitter to tree pos so it looks organic
    treePos.x += (Math.random() - 0.5) * 0.5;
    treePos.z += (Math.random() - 0.5) * 0.5;
    treePos.y += (Math.random() - 0.5) * 0.5;

    // 3. Calculate Scatter Position
    const scatterPos = getRandomSpherePos(SCATTER_RADIUS);

    // 4. Random Rotation
    const rotation = new THREE.Euler(
      Math.random() * Math.PI,
      Math.random() * Math.PI,
      Math.random() * Math.PI
    );

    particles.push({
      id: i,
      type,
      treePosition: treePos,
      scatterPosition: scatterPos,
      rotation,
      scale: scale * (0.8 + Math.random() * 0.4), // Random size variation
      color
    });
  }

  return particles;
};