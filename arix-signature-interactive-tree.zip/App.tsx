import React, { useState, useEffect } from 'react';
import { Scene } from './components/Scene';
import { AppMode } from './types';
import { Audio } from './components/Audio'; // Placeholder logic for audio

const App: React.FC = () => {
  const [mode, setMode] = useState<AppMode>(AppMode.SCATTERED);
  const [isReady, setIsReady] = useState(false);

  // Initial intro animation
  useEffect(() => {
    const timer = setTimeout(() => setIsReady(true), 100);
    return () => clearTimeout(timer);
  }, []);

  const toggleMode = () => {
    setMode((prev) => 
      prev === AppMode.SCATTERED ? AppMode.TREE_SHAPE : AppMode.SCATTERED
    );
  };

  return (
    <div className="relative w-full h-screen bg-[#050203] text-[#FCE4EC] font-sans overflow-hidden">
      
      {/* 3D Canvas Layer */}
      <div className={`absolute inset-0 transition-opacity duration-1000 ${isReady ? 'opacity-100' : 'opacity-0'}`}>
        <Scene mode={mode} />
      </div>

      {/* UI Overlay */}
      <main className="absolute inset-0 pointer-events-none flex flex-col justify-between p-8 md:p-12 z-10">
        
        {/* Header */}
        <header className="flex justify-between items-start">
          <div className="animate-fade-in-down">
            <h1 className="text-4xl md:text-6xl font-serif tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-pink-200 via-white to-pink-200 drop-shadow-[0_0_10px_rgba(255,255,255,0.5)]">
              ARIX
            </h1>
            <p className="text-pink-300/80 text-sm tracking-[0.3em] uppercase mt-2 ml-1">
              Signature Collection
            </p>
          </div>
        </header>

        {/* Center / Bottom Controls */}
        <div className="flex flex-col items-center gap-6 mb-8 pointer-events-auto">
            
          <p className={`text-center max-w-md text-pink-100/70 italic transition-opacity duration-500 ${mode === AppMode.SCATTERED ? 'opacity-100' : 'opacity-0 h-0'}`}>
             "In chaos, we find potential. Gather the magic."
          </p>
          
          <button
            onClick={toggleMode}
            className="group relative px-8 py-4 bg-transparent overflow-hidden rounded-full border border-pink-300/30 backdrop-blur-md transition-all duration-500 hover:border-pink-200 hover:bg-white/5 active:scale-95"
          >
            {/* Glow Effect behind button */}
            <div className="absolute inset-0 bg-pink-500/20 blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
            
            <span className="relative z-10 font-serif text-lg tracking-widest text-pink-100 group-hover:text-white transition-colors flex items-center gap-3">
              {mode === AppMode.SCATTERED ? (
                <>
                  <span>ASSEMBLE TREE</span>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                </>
              ) : (
                <>
                  <span>SCATTER GIFTS</span>
                   <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" /></svg>
                </>
              )}
            </span>
          </button>
        </div>

        {/* Footer */}
        <footer className="flex justify-between items-end text-xs text-pink-400/50 tracking-wider">
          <div>
            &copy; 2024 Arix Interactive. <br/>
            Merry Christmas.
          </div>
          <div className="text-right hidden md:block">
             DRAG TO ROTATE <br/>
             SCROLL TO ZOOM
          </div>
        </footer>
      </main>

    </div>
  );
};

export default App;